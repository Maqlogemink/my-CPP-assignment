#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

int main() {
    int n;
    std::cin >> n;

    // Membaca harga bitcoin untuk n hari
    vector<int> prices(n);
    for (int i = 0; i < n; ++i) {
        cin >> prices[i];
    }

    int maxProfit = 0;
    int currentBuy = -1; // Menunjukkan belum membeli
    vector<pair<int, int>> transactions; // Untuk menyimpan transaksi beli/jual

    for (int i = 0; i < n - 1; ++i) {
        if (prices[i] < prices[i + 1] && currentBuy == -1) {
            // Jika harga besok lebih tinggi dan kita belum membeli, kita beli hari ini
            currentBuy = prices[i];
        } else if (prices[i] > prices[i + 1] && currentBuy != -1) {
            // Jika harga besok lebih rendah dan kita sudah membeli, kita jual hari ini
            maxProfit += prices[i] - currentBuy;
            transactions.push_back({currentBuy, prices[i]});
            currentBuy = -1; // Reset, kita harus beli lagi sebelum bisa jual
        }
    }

    // Cek apakah kita masih memegang bitcoin pada hari terakhir
    if (currentBuy != -1 && prices[n - 1] > currentBuy) {
        maxProfit += prices[n - 1] - currentBuy;
        transactions.push_back({currentBuy, prices[n - 1]});
    }

    // Mencetak tabel transaksi
    cout << "-------------------------------------" << endl;
    cout << left << std::setw(10) << "| Beli" << setw(10) << "| Jual" << setw(15) << "| Keuntungan |" << endl;
    cout << "-------------------------------------" << endl;
    for (const auto& transaction : transactions) {
        int buy = transaction.first;
        int sell = transaction.second;
        cout << left << setw(10) << "| " + to_string(buy) << setw(10) << "| " + to_string(sell) << setw(15) << "| " + to_string(sell - buy) + " |" << endl;
    }
    cout << "-------------------------------------" << endl;
    cout << "Total Keuntungan: " << maxProfit << endl;

    return 0;
}
    