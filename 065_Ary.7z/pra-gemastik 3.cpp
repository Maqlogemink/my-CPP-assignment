#include <iostream>
#include <vector>
#include <queue>
#include <cmath>
#include <climits>
#include <algorithm>

using namespace std;

typedef pair<int, int> pii;

vector<int> dijkstra(int N, const vector<vector<int>>& graph, const vector<int>& heights, int start) {
    vector<int> dist(N, INT_MAX);
    dist[start] = 0;
    priority_queue<pii, vector<pii>, greater<pii>> pq;
    pq.push({0, start});

    while (!pq.empty()) {
        auto [d, u] = pq.top();
        pq.pop();

        if (d > dist[u]) continue;

        for (int v : graph[u]) {
            int cost = abs(heights[u] - heights[v]);
            if (dist[u] + cost < dist[v]) {
                dist[v] = dist[u] + cost;
                pq.push({dist[v], v});
            }
        }
    }

    return dist;
}

vector<int> min_fatigue(int N, int M, const vector<int>& heights, const vector<pair<int, int>>& edges) {
    vector<vector<int>> graph(N);
    for (const auto& [u, v] : edges) {
        graph[u - 1].push_back(v - 1);
        graph[v - 1].push_back(u - 1);
    }

    vector<int> results(N, 0);

    // Initial distances without any power usage
    auto original_distances = dijkstra(N, graph, heights, 0);

    results[0] = 0; // Day 1, no travel required

    for (int i = 2; i <= N; ++i) {
        int min_fatigue = original_distances[i - 1];
        for (int j = 0; j < N; ++j) {
            if (j == i - 1) continue;

            vector<int> modified_heights = heights;
            modified_heights[j] = heights[i - 1];

            auto new_distances = dijkstra(N, graph, modified_heights, 0);
            min_fatigue = min(min_fatigue, new_distances[i - 1]);
        }
        results[i - 1] = min_fatigue;
    }

    return results;
}

int main() {
    int N, M;
    cin >> N >> M;
    vector<int> heights(N);
    for (int i = 0; i < N; ++i) {
        cin >> heights[i];
    }

    vector<pair<int, int>> edges(M);
    for (int i = 0; i < M; ++i) {
        int u, v;
        cin >> u >> v;
        edges[i] = {u, v};
    }

    vector<int> result = min_fatigue(N, M, heights, edges);

    for (int i = 0; i < N; ++i) {
        cout << result[i] << " ";
    }
    cout << endl;

    return 0;
}
