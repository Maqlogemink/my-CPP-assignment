#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <iomanip>
using namespace std;

int main() {
    int N, X;
    cin >> N >> X;

    vector<int> kuponPeserta(N);
    for (int i = 0; i < N; ++i) {
        cin >> kuponPeserta[i];
    }

    int jarakMinimum = numeric_limits<int>::max();
    vector<int> pemenang;

    for (int i = 0; i < N; ++i) {
        int jarak = abs(kuponPeserta[i] - X);
        if (jarak < jarakMinimum) {
            jarakMinimum = jarak;
            pemenang.clear();
            pemenang.push_back(kuponPeserta[i]);
        } else if (jarak == jarakMinimum) {
            pemenang.push_back(kuponPeserta[i]);
        }
    }

    sort(pemenang.begin(), pemenang.end());

    cout << "•-------•" << endl;
    cout << "| Kupon |" << endl;
    cout << "•-------•" << endl;

    for (int i = 0; i < pemenang.size(); ++i) {
        cout << "| " << setw(5) << setfill('0') << pemenang[i] << " |" << endl;
    }

    cout << "•-------•" << endl;

    return 0;
}
