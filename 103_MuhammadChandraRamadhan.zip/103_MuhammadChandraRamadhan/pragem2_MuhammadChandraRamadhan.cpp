#include<bits/stdc++.h>
using namespace std;
//Muhamamd Chandra Ramadhan (2201020103)
//Dibuat dengan C++17 , jika ada error gunakan compiler 17 keatas

int main(){
	int n , kupon, mins = 10000000, inp;
	cin >> n >> kupon;
	int arr[n];
	for(int i=0;i<n;i++){
		cin >> arr[i];
		mins = min(mins, abs(arr[i]-kupon));
	}sort(arr, arr + sizeof(arr)/sizeof(arr[0]));
	for(int i=0;i<n;i++){
		if(abs(arr[i]-kupon) == mins)
		cout << setw(5) << setfill('0') << arr[i] << endl;
	}
}
