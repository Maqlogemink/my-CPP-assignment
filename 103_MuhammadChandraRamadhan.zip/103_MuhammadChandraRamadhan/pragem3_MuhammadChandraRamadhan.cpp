#include<bits/stdc++.h>
#define ll long long
#define range(n) for(int i=0;i<n;++i)
#define sizes(x) int((x).size())

using namespace std;

//Muhamamd Chandra Ramadhan (2201020103)
//Dibuat dengan C++17 , jika ada error gunakan compiler online 17 keatas atau terbaru ( tidak disarankan devc++ )

template < class T>
bool mins(T& a, T b){
	if(b<a){a = b; return true;}
	return false;
}

int n, m, u, v;
array<vector<ll>,2> dist;

int main(){
	cin >> n >> m;
	vector<int> tinggi(n);
	vector< vector<int> >  jalur(n);
	range(n) cin >> tinggi[i];
	
	while(m--){
		cin >> u >> v;
		jalur[--u].emplace_back(--v);
		jalur[v].emplace_back(u);
	}
	
	range(n) {
		sort(begin(jalur[i]), end(jalur[i]), [&](int u, int v){ return tinggi[u] < tinggi[v];});	
	}
	auto dijkstra= [&](vector<ll>& dist){
		priority_queue < pair < ll, int>, vector<pair< ll, int>> , greater< pair<ll, int>>> pq;
		range(n){
			if(dist[i] < LLONG_MAX){
				pq.emplace(dist[i], i);
			}
		}
		while(sizes(pq)){
			auto [dis_u ,u] = pq.top();
			pq.pop();
			if(dis_u != dist[u])continue;
			for(int v:jalur[u]){
				if(mins(dist[v], dis_u+abs(tinggi[u]- tinggi[v]))){
					pq.emplace(dist[v], v);
				}
			}
		}
	};
	
	dist[0].resize(n, LLONG_MAX);
	dist[0][0] = 0;
	dijkstra(dist[0]);
	dist[1] = dist[0];
	for(int v:jalur[0]) dist[1][v] 	= 0;
	for(int i=1;i<n;++i){
		{
			ll mn = LLONG_MAX;
			for(int j=0; j<sizes(jalur[i]);++j){
				int u= jalur[i][j];
				mins(mn, dist[0][u] - tinggi[u]);
				mins(dist[1][u], mn+tinggi[u]);
			}
		}
		{
			
			ll mn = LLONG_MAX;
			for(int j=sizes(jalur[i])-1;j>=0;--j){
				int u = jalur[i][j];
				mins(mn, dist[0][u] + tinggi[u]);
				mins(dist[1][u], mn - tinggi[u]);
			}
		}
	}
	
	dijkstra(dist[1]);
	for(int u=0;u<n;++u){
		for( int v:jalur[u]) mins(dist[1][v], dist[0][u]);
	}
	range(n)cout << " " + (i==0) << dist[1][i];
	
}

