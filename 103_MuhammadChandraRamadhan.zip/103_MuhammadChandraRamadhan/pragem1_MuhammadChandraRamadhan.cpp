#include<iostream>
#include<algorithm>
using namespace std;
//Muhamamd Chandra Ramadhan (2201020103)
//Dibuat dengan C++17 , jika ada error gunakan compiler 17 keatas

int main(){
	int n,inp,temp=1000001,keuntungan=0; cin >> n;
	for(int i=0;i<n;i++){
		cin >> inp;
		keuntungan += max(0,inp-temp );
		temp = inp;
	}cout << keuntungan;
}
