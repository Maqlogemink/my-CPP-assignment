#include <bits/stdc++.h>
using namespace std;

const int maxn = 5e4+3;
const long long inf = 1e18;
int n, m;
long long h[maxn];
vector<int> adjl[maxn];
long long dist[maxn][2];
priority_queue<pair<long long, int>> pq;
bool vis[maxn];

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    cin >> n >> m;
    for (int i = 1; i <= n; i++) cin >> h[i];
    
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        adjl[u].push_back(v);
        adjl[v].push_back(u);
    }

    memset(vis, false, sizeof(vis));
    for (int i = 0; i <= n; i++) dist[i][0] = dist[i][1] = inf;
    dist[1][0] = 0;
    pq.emplace(0, 1);

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();
        if (vis[u]) continue;
        vis[u] = true;

        for (int v : adjl[u]) {
            if (dist[u][0] + abs(h[u] - h[v]) < dist[v][0]) {
                dist[v][0] = dist[u][0] + abs(h[u] - h[v]);
                pq.emplace(-dist[v][0], v);
            }
        }
    }

    for (int i = 1; i <= n; i++) {
        sort(adjl[i].begin(), adjl[i].end(), [&](int u, int v) {
            return h[u] < h[v];
        });

        vector<long long> pref(adjl[i].size()), suff(adjl[i].size());
        if (!adjl[i].empty()) {
            pref[0] = dist[adjl[i][0]][0] - h[adjl[i][0]];
            for (int j = 1; j < adjl[i].size(); j++) {
                pref[j] = min(pref[j - 1], dist[adjl[i][j]][0] - h[adjl[i][j]]);
            }

            suff[adjl[i].size() - 1] = dist[adjl[i].back()][0] + h[adjl[i].back()];
            for (int j = adjl[i].size() - 2; j >= 0; j--) {
                suff[j] = min(suff[j + 1], dist[adjl[i][j]][0] + h[adjl[i][j]]);
            }

            for (int j = 0; j < adjl[i].size(); j++) {
                dist[adjl[i][j]][1] = min(dist[adjl[i][j]][1], min(pref[j] + h[adjl[i][j]], suff[j] - h[adjl[i][j]]));
            }
        }
    }

    for (int v : adjl[1]) dist[v][1] = 0;

    memset(vis, false, sizeof(vis));
    for (int i = 1; i <= n; i++) pq.emplace(-dist[i][1], i);

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();
        if (vis[u]) continue;
        vis[u] = true;

        for (int v : adjl[u]) {
            if (dist[u][1] + abs(h[u] - h[v]) < dist[v][1]) {
                dist[v][1] = dist[u][1] + abs(h[u] - h[v]);
                pq.emplace(-dist[v][1], v);
            }
        }
    }

    for (int i = 1; i <= n; i++) {
        for (int v : adjl[i]) {
            dist[v][1] = min(dist[v][1], dist[i][0]);
        }
    }

    for (int i = 1; i <= n; i++) cout << dist[i][1] << ' ';
    cout << '\n';

    return 0;
}
