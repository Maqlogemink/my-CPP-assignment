#include<iostream>
#include<algorithm>
#include<iomanip>
#include<cmath>
using namespace std;

int main() {
    int n, g;
    cin >> n >> g;
    int m = g;
    int k[n];
    for (int i = 0; i < n; i++) {
        cin >> k[i];
        int d = abs(g - k[i]);
        m = min(d, m);
    }
    int size = sizeof(k) / sizeof(k[0]);
    sort(k, k + size);
    for (int i = 0; i < size; i++) {
        if (abs(g - k[i]) == m) {
            cout << setw(5) << setfill('0') << k[i] << endl;
        }
    }
    return 0;
}
