#include <iostream>
using namespace std;

int main() {
    int n, profit = 0, prev, curr;
    cin >> n >> prev;
    for (int i = 1; i < n; ++i) {
        cin >> curr;
        profit += max(0, curr - prev);
        prev = curr;
    }
    cout << profit << endl;
}

